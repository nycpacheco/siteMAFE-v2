# MAFE em Harmonia

INSTRUÇÃO DE LIMPEZA E ORGANIZAÇÃO:

Por favor, faça uma varredura geral na estrutura do projeto e limpe a base de código do MAFE, seguindo rigorosamente estas etapas em uma única execução:

1. REMOÇÃO DE CÓDIGO MORTO / INÚTIL:

   - Identifique e remova todos os componentes, páginas, rotas ou arquivos .tsx/.jsx de exemplo que NÃO pertencem às 4 telas ativas (Início, Quem Somos, Galeria, Apoiadores).

   - Remova variáveis não utilizadas, imports duplicados ou sem uso (especialmente de ícones) e arquivos de assets que não estão sendo renderizados em lugar nenhum.

2. ORGANIZAÇÃO E CONSOLIDAÇÃO:

   - Certifique-se de que todas as rotas (Início, Quem Somos, Galeria e Apoiadores) estejam limpas e integradas corretamente ao SiteFrame.

   - Garanta que o estilo Neobrutalista, as cores (#FFF8ED, #F56D00, #6C0812, #140E0C) e a acessibilidade (WCAG para idosos 60+) continuem 100% preservadas.

3. FINALIZAÇÃO:

   - Certifique-se de que o projeto esteja pronto para build e sem nenhum erro de TypeScript, CSS ou rotas quebradas.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/6ce3adfd-050b-4aa8-b47d-0c725fa0e986).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
