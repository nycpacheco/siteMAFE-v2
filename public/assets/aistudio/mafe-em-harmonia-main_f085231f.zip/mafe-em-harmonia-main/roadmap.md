# Current request — React prototype
- [x] Update the React home, shared header and footer to match the newly supplied prototypes.
- [x] Verify React carousels, mobile navigation, themes, loaded images and narrow-screen overflow.
- Supporter logos, official descriptions/sites and the actual group photo await separate source assets; retain illustrative media and labeled pending details.

## Previous standalone delivery
- Superseded by the latest React-only brief; standalone HTML and ZIP work is not part of this iteration.