<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project architecture

- Keep public content in `src/lib/site-content.ts` so the future CMS can replace data without rewriting presentation components.
- Wrap public routes with `SiteFrame` in the root route so accessibility controls and navigation remain consistent.
- Keep the home structure and both carousel states together in the index route; use the shared SiteFrame for navigation and themes so all public pages stay consistent.
- Use Embla for home carousel scrolling and Radix Dialog for supporter details to preserve keyboard and focus behavior.
- Keep standalone HTML deliveries separate from the TanStack preview, with shared external CSS and JavaScript and complete HTML navigation — the downloadable site must run without a framework or installation.
