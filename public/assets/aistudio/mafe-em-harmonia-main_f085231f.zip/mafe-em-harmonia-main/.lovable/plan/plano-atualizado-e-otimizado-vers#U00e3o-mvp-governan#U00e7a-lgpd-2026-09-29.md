# Plano Atualizado e Otimizado (Versão MVP + Governança & LGPD)

### Objetivo

Criar a interface pública e acessível da plataforma **Maturidade Feliz** em React, priorizando o público da terceira idade, atendendo integralmente ao escopo do MVP e aplicando as estratégias de mitigação de riscos de imagem/LGPD.

### 1. Estrutura de Páginas e Navegação (Rotas React)

- `/` **(Página Inicial / Home):**
  - **Cabeçalho:** Logotipo/Nome (*Maturidade Feliz* / *MAFE* em telas reduzidas), menu simples e botão fixo/destacado **“Participar”** (direcionando para o WhatsApp pessoal da coordenadora Ângela).
  - **Bloco de Avisos Rápidos:** Espaço em destaque para avisos oficiais atualizados.
  - **Seção "Quem Somos":** Apresentação emocional do grupo, história e a importância do esporte para a saúde dos idosos.
  - **Seção "Treinos Regulares":** Exibição pública de local e horário oficial: *Mairiporã — Sábados, das 9h às 13h* (formato aberto/inclusivo).
  - **Seção "Apoiadores e Patrocinadores":** Grid estruturado para os 4 apoiadores atuais, com logos, textos explicativos e links.
  - **Seção "Sobre o Grupo em Números":** Estrutura visual pronta para exibir total de participantes, anos de atuação e estatísticas do grupo.
  - **Chamada para a Galeria:** Preview com acesso direto à página completa de mídias.
- `/galeria` **(Galeria de Mídias):**
  - Suporte para **fotos** (~100 iniciais) e **vídeos** (players embutidos do YouTube).
  - Sistema de filtros encadeados em dois níveis obrigatórios: **Ano → Tipo de Evento (Treinos ou Competições)**.
  - Modals de visualização ampliada com legendas descritivas e datas.
- `/login` **(Acesso Administrativo - Opcional no menu, visível no rodapé):**
  - Atalho discreto para a tela de login único compartilhado da coordenadora.

### 2. Acessibilidade Digital e Design System (RNF01 a RNF13)

- **Abordagem *Mobile-First*:** Layout e interações desenhados e testados prioritariamente para telas de smartphones.
- **Tipografia e Alvos de Toque:** Fontes ampliadas por padrão, botões e ícones com áreas de clique grandes para facilitar o manuseio por idosos.
- **Controle de Alto Contraste:** Botão acessível e persistente durante a navegação, que alterna a interface para fundo escuro com texto de alto contraste.
- **Paleta de Cores Oficial:**
  - *Cor Dominante/Marca:* Laranja abóbora (`#F07A1A`).
  - *Textos e Botões Principais:* Bordô ou Preto/Chumbo (para garantir legibilidade).
  - *Fundo e Base:* Branco / Laranja e Amarelo sol apenas em elementos gráficos e de destaque.

### 3. Rodapé Institucional e Trava de Governança/LGPD (RN06)

- **Contatos Oficiais:** E-mail do grupo, link para o Facebook e botão direto para o WhatsApp.
- **Canal de Privacidade e Remoção de Imagem (Mitigação de Risco LGPD):**
  > *"Aparece em alguma de nossas fotos ou vídeos e deseja a remoção? Entre em contato pelo nosso WhatsApp/E-mail e removeremos o conteúdo imediatamente."*
- **Crédito Acadêmico:** Mensagem discreta *"Desenvolvido por alunos do IFSP"* (sem logotipos ou regras institucionais do IFSP).

### 4. Limites Rígidos do Escopo (O que NÃO será construído)

- Sem páginas ou funcionalidades de **Calendário/Agenda automatizada**.
- Sem página de **Notícias** ou formulários/cadastros de atletas.
- Sem integração com **Instagram** ou botões para WhatsApp corporativo.
- Sem divulgação de treinos extras/seletivas fechadas para campeonatos.

### 5. Detalhes Técnicos de Infraestrutura

- **Front-end:** Desenvolvido estritamente em **React** (utilizando Next.js/Gatsby para SSG/Geração Estática).
- **Gestão de Mídia:** Fotos otimizadas hospedadas no Cloudinary/Supabase Storage; vídeos rodando via `iframe` do YouTube (custo R$ 0,00).
- **Separação de Dados:** Estrutura em JSON/CMS isolada do componente visual para facilitar a conexão futura com o Painel Administrativo.