# Plano: Remover abas e trocar apoiadores por pop-up

## O que muda

### 1. Remover as abas "Calendário" e "Notícias"
- `src/components/site-frame.tsx`: remover os dois itens do array `navItems` (menu desktop e celular ficam automáticos).
- Excluir `src/routes/calendario.tsx` e `src/routes/noticias.tsx` (eram páginas "Em breve" vazias; sem rota, nenhum link quebra).
- O menu fica: Início, Quem somos, Apoiadores, Galeria.

### 2. Apoiadores: pop-up estilo Galeria no lugar do painel lateral
- `src/routes/apoiadores.tsx`: remover o `<aside>` lateral e o estado `selected`.
- Cada card de apoiador vira um `Dialog` (igual aos cards da galeria):
  - **Fechado (card):** logo/ícone, nome e um mini texto (categoria).
  - **Aberto (pop-up):** nome, categoria/descrição do apoiador, botão "Visitar site oficial" (quando houver URL), botão "Falar com a coordenação" (WhatsApp) e a nota de que nome/logo ainda serão informados pela coordenação.
- Manter o bloco "Quer apoiar o MAFE?" abaixo da grade de cards (fora do pop-up).
- Todos os textos em português, fontes grandes e botões grandes (público 3ª idade).

### 3. Validação
- Build OK e conferência no navegador: menu sem as duas abas, pop-up abre com as informações completas, nada quebra.

## Arquivos tocados
- `src/components/site-frame.tsx` (editar)
- `src/routes/apoiadores.tsx` (reescrever)
- `src/routes/calendario.tsx`, `src/routes/noticias.tsx` (excluir)
