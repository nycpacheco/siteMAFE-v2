Conversão e Aprimoramento do Site Estático do MAFE (HTML/CSS/JS)

O usuário solicita a conversão e o aprimoramento completo do projeto para arquivos HTML, CSS e JavaScript puros e separados (.html, .css, .js), focando na acessibilidade e usabilidade para o público da terceira idade da equipe Maturidade Feliz (MAFE).

Passos

1. Base de Design e Organização de Arquivos

   - **Referência Visual Obrigatória:** Utilizar estritamente o design moderno e a estrutura visual criados na versão em **React** do projeto como base para este protótipo, descartando totalmente o protótipo HTML anterior.

   - Separar estritamente o código em arquivos individuais (.html, .css e .js), evitando qualquer mistura de scripts ou estilos em arquivo único.

   - Adotar abordagem mobile-first, garantindo comportamento impecável tanto em dispositivos móveis quanto em desktops.

2. Cabeçalho (Header) e Navegação

   - Posicionar à esquerda o logotipo oficial ("VOLLEYBALL" dentro de um quadro branco arredondado) e o título da equipe.

   - Centralizar os links de navegação principal: "Início", "Quem Somos", "Galeria", "Apoiadores".

   - Inserir à direita os botões interativos utilizando os SVGs oficiais:

     * Botão de Acessibilidade com o ícone Lucide `lucide-accessibility`).

     * Botão de Alternância de Tema com o ícone de lua Lucide `lucide-moon`).

     * Botão de destaque "Participar" estilizado na cor bordo/vinho tradicional.

3. Estruturação da Página Inicial (Início)

   - Desenvolver uma estrutura limpa, direta e modular, projetada para evitar rolagem excessiva (a página inicial deve caber essencialmente na visualização principal, sem scroll infinito desnecessário).

   - Organizar o conteúdo em blocos arejados: seção de destaques/momentos que ficam, caixa lateral de contato e bloco rápido de apoiadores, livres de poluição visual.

4. Aba de Apoiadores

   - Estruturar os cards de apoiadores em grade responsiva com proporções refinadas, fáceis de tocar, logotipos nítidos e botões de ação ("Ver mais") bem destacados.

   - Garantir que páginas densas (como Apoiadores ou Quem Somos) limitem-se a no máximo 3 telas de altura.

5. Sistema de Temas (Modo Claro e Modo Escuro) e Feedback Visual

   - **Modo Claro (Padrão):** Fundo em tons claros/neutros, detalhes em laranja vibrante e elementos de identidade em bordo/vinho.

   - **Modo Escuro:** Fundos pretos ou cinzas muito escuros, laranjas vivos para destaques, textos em branco para legibilidade máxima, reservando o bordo/vinho para hovers, contornos e detalhes decorativos.

   - **Feedback Visual de Hover:** Implementar animações e mudanças claras de tom (clareamento, acendimento ou exibição de borda/traçado nítido) em absolutamente todos os elementos interativos para orientar visualmente onde o cursor está.

Observações

- Foco absoluto em acessibilidade para a 3ª idade: tipografia altamente legível, botões grandes, áreas de clique generosas e atributos `alt` adequados nas imagens.

- Utilizar imagens genéricas de alta qualidade ou placeholders para decoração e preenchimento visual inicial onde necessário.

- Entregar a estrutura completa, limpa, bem comentada e dividida nos arquivos correspondentes.