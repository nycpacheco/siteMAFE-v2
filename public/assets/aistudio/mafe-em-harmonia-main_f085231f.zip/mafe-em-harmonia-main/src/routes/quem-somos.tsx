import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarHeart, Images, MessageCircle, Trophy, Users } from "lucide-react";

import groupImage from "@/assets/mafe-treino-grupo.jpg";
import portraitImage from "@/assets/mafe-retrato-equipe.jpg";
import { PageBanner } from "@/components/page-banner";
import { Button } from "@/components/ui/button";
import { aboutContent } from "@/lib/site-content";

export const Route = createFileRoute("/quem-somos")({
  head: () => ({
    meta: [
      { title: "Quem somos — Maturidade Feliz" },
      {
        name: "description",
        content:
          "Desde 2019, o MAFE oferece vôlei adaptado para pessoas idosas em Mairiporã-SP pelo programa Escola da Família.",
      },
      { property: "og:title", content: "Quem somos — Maturidade Feliz" },
      {
        property: "og:description",
        content: "Conheça a história do grupo de vôlei adaptado Maturidade Feliz.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AboutPage,
});

const facts = [
  { icon: CalendarHeart, value: `Desde ${aboutContent.since}`, label: "em quadra" },
  { icon: Users, value: "~60 pessoas", label: "de 45 a 75 anos" },
  { icon: Trophy, value: "Torneios", label: "e competições" },
];

function AboutPage() {
  return (
    <>
      <PageBanner
        eyebrow="Nossa história"
        title="Quem somos"
        text="Vôlei adaptado, saúde e amizade em Mairiporã."
      />
      <section className="section-space">
        <div className="page-shell grid gap-6">
          <article className="visible-card grid gap-5 p-5 md:grid-cols-[1.1fr_0.9fr] md:items-center md:p-8">
            <div>
              <span className="inline-block rounded-md bg-soft px-3 py-1 text-sm font-extrabold uppercase text-primary">
                Quem somos
              </span>
              <h2 className="mt-2 font-display text-3xl font-black">Um pouco sobre nós</h2>
              <p className="mt-3 text-lg">
                Atuando desde {aboutContent.since}, o grupo social{" "}
                <strong className="text-primary">MAFE — Maturidade Feliz</strong> desenvolve, na
                cidade de {aboutContent.city}, aulas de vôlei adaptado para pessoas idosas por meio
                de um programa da Prefeitura Municipal chamado{" "}
                <strong>{aboutContent.program}</strong>, buscando aumentar a qualidade de vida da
                população local.
              </p>
              <p className="mt-3 text-lg">
                O projeto atende{" "}
                <strong className="text-primary">{aboutContent.participants}</strong> em encontros
                semanais que se estendem para torneios e competições, ampliando não só a saúde
                física, mas também a socialização e o bem-estar emocional dos participantes.
              </p>
            </div>
            <img
              src={groupImage}
              alt="Participantes do MAFE reunidos na quadra"
              width={1600}
              height={1008}
              className="aspect-[4/3] w-full rounded-lg border-4 border-foreground object-cover"
            />
          </article>

          <div className="grid gap-3 sm:grid-cols-3">
            {facts.map(({ icon: Icon, value, label }) => (
              <div
                key={value}
                className="flex items-center gap-3 rounded-lg border-4 border-foreground bg-card p-4"
              >
                <Icon aria-hidden="true" className="size-9 shrink-0 text-primary" />
                <div>
                  <p className="font-display text-2xl font-black">{value}</p>
                  <p className="font-bold">{label}</p>
                </div>
              </div>
            ))}
          </div>

          <article className="visible-card grid gap-5 p-5 md:grid-cols-[0.9fr_1.1fr] md:items-center md:p-8">
            <img
              src={portraitImage}
              alt="Equipe do MAFE com uniformes laranja"
              width={1200}
              height={912}
              loading="lazy"
              className="aspect-[4/3] w-full rounded-lg border-4 border-foreground object-cover"
            />
            <div>
              <span className="inline-block rounded-md bg-soft px-3 py-1 text-sm font-extrabold uppercase text-primary">
                Nossa história
              </span>
              <h2 className="mt-2 font-display text-3xl font-black">Onde tudo começou</h2>
              <p className="mt-3 text-lg">
                O grupo nasceu do desejo de oferecer às pessoas idosas um espaço de movimento,
                acolhimento e amizade. Cada pessoa joga no seu ritmo, com respeito e cooperação.
              </p>
              <div className="mt-5 grid gap-3 sm:flex">
                <Button
                  variant="participate"
                  size="lg"
                  onClick={() =>
                    window.alert("O número oficial da coordenadora ainda precisa ser informado.")
                  }
                >
                  <MessageCircle aria-hidden="true" /> Participar
                </Button>
                <Button variant="outline" size="lg" className="border-2" asChild>
                  <Link to="/galeria">
                    <Images aria-hidden="true" /> Ver galeria
                  </Link>
                </Button>
              </div>
            </div>
          </article>
        </div>
      </section>
    </>
  );
}
