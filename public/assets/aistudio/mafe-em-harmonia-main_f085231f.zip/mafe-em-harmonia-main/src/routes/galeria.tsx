import { createFileRoute } from "@tanstack/react-router";
import { CalendarDays, ImageIcon, Info, PlayCircle, Search } from "lucide-react";
import { useMemo, useState } from "react";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { galleryItems } from "@/lib/site-content";

export const Route = createFileRoute("/galeria")({
  head: () => ({
    meta: [
      { title: "Galeria — Maturidade Feliz" },
      {
        name: "description",
        content:
          "Fotos e vídeos dos treinos e competições do grupo Maturidade Feliz, organizados por ano e tipo de evento.",
      },
      { property: "og:title", content: "Galeria — Maturidade Feliz" },
      {
        property: "og:description",
        content: "Conheça a história do Maturidade Feliz por meio de fotos e vídeos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GalleryPage,
});

function GalleryPage() {
  const [year, setYear] = useState("Todos");
  const [eventType, setEventType] = useState("Todos");
  const filtered = useMemo(
    () =>
      galleryItems.filter(
        (item) =>
          (year === "Todos" || item.year === year) &&
          (eventType === "Todos" || item.eventType === eventType),
      ),
    [year, eventType],
  );

  return (
    <>
      <section className="orange-band py-10 md:py-14">
        <div className="page-shell">
          <span className="eyebrow text-foreground">Fotos e vídeos</span>
          <h1 className="font-display text-5xl font-black md:text-7xl">Galeria</h1>
          <p className="mt-4 max-w-3xl text-xl font-bold">
            Memórias de treinos, encontros e competições do Maturidade Feliz.
          </p>
        </div>
      </section>
      <section className="section-space">
        <div className="page-shell">
          <div className="visible-card p-5 md:p-8">
            <div className="flex items-start gap-3 rounded-md bg-soft p-4">
              <Info className="mt-1 size-6 shrink-0 text-primary" />
              <p>
                <strong>Como encontrar uma lembrança:</strong> escolha primeiro o ano e depois o
                tipo de evento. Toque em uma foto para ampliar e ler a história.
              </p>
            </div>
            <div className="mt-7 grid gap-5 md:grid-cols-2">
              <label className="block font-bold">
                <span className="mb-2 flex items-center gap-2">
                  <CalendarDays className="size-6 text-primary" /> 1. Escolha o ano
                </span>
                <Select value={year} onValueChange={setYear}>
                  <SelectTrigger className="min-h-14 border-2 bg-card px-4 text-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todos" className="min-h-12 text-lg">
                      Todos os anos
                    </SelectItem>
                    <SelectItem value="2026" className="min-h-12 text-lg">
                      2026
                    </SelectItem>
                  </SelectContent>
                </Select>
              </label>
              <label className="block font-bold">
                <span className="mb-2 flex items-center gap-2">
                  <VolleyballFilterIcon /> 2. Escolha o tipo
                </span>
                <Select value={eventType} onValueChange={setEventType}>
                  <SelectTrigger className="min-h-14 border-2 bg-card px-4 text-lg">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Todos" className="min-h-12 text-lg">
                      Todos os tipos
                    </SelectItem>
                    <SelectItem value="Treinos" className="min-h-12 text-lg">
                      Treinos
                    </SelectItem>
                    <SelectItem value="Competições" className="min-h-12 text-lg">
                      Competições
                    </SelectItem>
                  </SelectContent>
                </Select>
              </label>
            </div>
          </div>
          <div className="mt-8 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <h2 className="section-title text-3xl">Resultados</h2>
            <p aria-live="polite" className="text-lg font-bold">
              {filtered.length}{" "}
              {filtered.length === 1 ? "registro encontrado" : "registros encontrados"}
            </p>
          </div>
          {filtered.length > 0 ? (
            <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((item) => (
                <Dialog key={item.id}>
                  <DialogTrigger asChild>
                    <button className="visible-card group overflow-hidden text-left focus-visible:ring-4 focus-visible:ring-ring">
                      <div className="relative">
                        <img
                          src={item.image}
                          alt={item.title}
                          width={item.width}
                          height={item.height}
                          loading="lazy"
                          className="aspect-[4/3] w-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                        />
                        <span className="absolute left-3 top-3 rounded-md bg-footer px-3 py-1 font-bold text-footer-foreground">
                          {item.mediaType === "Vídeo" ? (
                            <PlayCircle />
                          ) : (
                            <ImageIcon className="inline size-5" />
                          )}{" "}
                          {item.mediaType}
                        </span>
                      </div>
                      <div className="p-5">
                        <p className="font-display text-xl font-bold">{item.title}</p>
                        <p className="mt-2 text-muted-foreground">
                          {item.date} · {item.eventType}
                        </p>
                        <p className="mt-3 line-clamp-2">{item.description}</p>
                        <span className="mt-4 inline-flex items-center gap-2 font-bold text-primary">
                          <Search className="size-5" /> Ampliar
                        </span>
                      </div>
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-h-[92vh] max-w-4xl overflow-y-auto border-4 p-4 sm:p-6">
                    <img
                      src={item.image}
                      alt={item.title}
                      width={item.width}
                      height={item.height}
                      className="max-h-[65vh] w-full rounded-md object-contain"
                    />
                    <DialogHeader>
                      <DialogTitle className="pr-10 text-2xl">{item.title}</DialogTitle>
                      <DialogDescription className="text-lg text-foreground">
                        {item.date} · {item.eventType}
                      </DialogDescription>
                    </DialogHeader>
                    <p className="text-lg">{item.description}</p>
                    <p className="rounded-md bg-soft p-3 text-base">
                      <strong>Aviso:</strong> imagem ilustrativa temporária, que será substituída
                      pelo acervo autorizado da cliente.
                    </p>
                  </DialogContent>
                </Dialog>
              ))}
            </div>
          ) : (
            <div className="mt-6 visible-card p-10 text-center">
              <Search className="mx-auto size-12 text-primary" />
              <h3 className="mt-4 text-2xl font-bold">Nenhum registro encontrado</h3>
              <p className="mt-2 text-lg">Escolha outra combinação de ano e tipo de evento.</p>
            </div>
          )}
          <p className="mt-8 rounded-md border-2 border-primary bg-soft p-5">
            <strong>Acervo em preparação:</strong> estas imagens são ilustrativas. A galeria está
            pronta para receber as fotos, legendas e vídeos reais selecionados pela coordenação.
          </p>
        </div>
      </section>
    </>
  );
}

function VolleyballFilterIcon() {
  return <ImageIcon aria-hidden="true" className="size-6 text-primary" />;
}
