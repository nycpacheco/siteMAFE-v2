import { createFileRoute } from "@tanstack/react-router";
import { ExternalLink, MessageCircle, Search } from "lucide-react";

import { PageBanner } from "@/components/page-banner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { supporters } from "@/lib/site-content";

export const Route = createFileRoute("/apoiadores")({
  head: () => ({
    meta: [
      { title: "Apoiadores — Maturidade Feliz" },
      {
        name: "description",
        content:
          "Empresas e parceiros que apoiam o vôlei adaptado do Maturidade Feliz em Mairiporã.",
      },
      { property: "og:title", content: "Apoiadores — Maturidade Feliz" },
      {
        property: "og:description",
        content: "Conheça quem apoia o Maturidade Feliz e saiba como se tornar parceiro.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SupportersPage,
});

function SupportersPage() {
  const askCoordination = () =>
    window.alert("O número oficial da coordenadora ainda precisa ser informado.");

  return (
    <>
      <PageBanner
        eyebrow="Quem torna isso possível"
        title="Apoiadores"
        text="Toque em um apoiador para ver os detalhes."
      />
      <section className="section-space">
        <div className="page-shell">
          <ul
            className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5"
            aria-label="Lista de apoiadores"
          >
            {supporters.map((s) => (
              <li key={s.id}>
                <Dialog>
                  <DialogTrigger asChild>
                    <button
                      type="button"
                      aria-label={`Ver mais sobre ${s.name}`}
                      className="group flex h-full w-full cursor-pointer flex-col overflow-hidden rounded-lg border-4 border-foreground bg-card text-left shadow-[4px_4px_0_var(--color-foreground)] transition hover:-translate-y-1"
                    >
                      <span className="block aspect-square w-full bg-logo-surface">
                        <img
                          src={s.logo}
                          alt=""
                          width={816}
                          height={816}
                          loading="lazy"
                          className="size-full object-contain"
                        />
                      </span>
                      <span className="flex flex-1 flex-col gap-1 p-4">
                        <span className="font-display text-xl font-black">{s.name}</span>
                        <span className="line-clamp-2 text-base">{s.summary}</span>
                        <span className="mt-2 flex min-h-12 items-center gap-2 text-lg font-black text-primary group-hover:underline">
                          <Search aria-hidden="true" className="size-5" /> Ver mais
                        </span>
                      </span>
                    </button>
                  </DialogTrigger>
                  <DialogContent className="max-h-[92vh] max-w-4xl overflow-y-auto border-4 border-foreground bg-card p-5 shadow-[6px_6px_0_var(--color-foreground)] sm:p-7 [&>button:last-child]:right-3 [&>button:last-child]:top-3 [&>button:last-child]:flex [&>button:last-child]:size-12 [&>button:last-child]:items-center [&>button:last-child]:justify-center [&>button:last-child]:rounded-md [&>button:last-child]:bg-action [&>button:last-child]:text-action-foreground [&>button:last-child]:opacity-100 [&>button:last-child_svg]:size-7">
                    <div className="grid gap-6 md:grid-cols-[minmax(0,2fr)_minmax(0,3fr)]">
                      <img
                        src={s.logo}
                        alt={`Logotipo de ${s.name}`}
                        width={816}
                        height={816}
                        className="aspect-square w-full rounded-md object-contain"
                      />
                      <div className="min-w-0 md:pt-8">
                        <DialogHeader className="text-left">
                          <DialogTitle className="pr-12 font-display text-3xl font-black">
                            {s.name}
                          </DialogTitle>
                          <DialogDescription className="text-xl text-foreground">
                            {s.description}
                          </DialogDescription>
                        </DialogHeader>
                        <Button
                          variant="participate"
                          size="lg"
                          className="mt-6 min-h-14 w-full text-xl sm:w-auto"
                          disabled={!s.url}
                          asChild={!!s.url}
                        >
                          {s.url ? (
                            <a href={s.url} target="_blank" rel="noreferrer">
                              Acessar site <ExternalLink aria-hidden="true" />
                            </a>
                          ) : (
                            <span>Site em atualização</span>
                          )}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </li>
            ))}
          </ul>
          <div className="mt-10 rounded-lg border-4 border-foreground bg-highlight p-5 text-foreground md:p-7">
            <p className="font-display text-2xl font-black">Quer apoiar o MAFE?</p>
            <p className="mt-1 text-lg">
              Empresas e parceiros podem entrar em contato para apoiar o grupo.
            </p>
            <Button
              variant="participate"
              size="lg"
              className="mt-4 min-h-14 w-full text-lg sm:w-auto"
              onClick={askCoordination}
            >
              <MessageCircle aria-hidden="true" /> Falar com a Coordenação
            </Button>
          </div>
        </div>
      </section>
    </>
  );
}
