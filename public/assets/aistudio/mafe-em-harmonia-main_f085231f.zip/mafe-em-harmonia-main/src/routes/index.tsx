import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, Facebook, HeartHandshake, Mail, Phone } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { contactStatus, galleryItems, homeContent, supporters } from "@/lib/site-content";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Maturidade Feliz (MAFE) — Início" },
      {
        name: "description",
        content:
          "Momentos, contatos e apoiadores da equipe de voleibol adaptado Maturidade Feliz em Mairiporã.",
      },
      { property: "og:title", content: "Maturidade Feliz (MAFE) — Início" },
      {
        property: "og:description",
        content: "Nossa história, momentos que ficam e quem apoia o MAFE.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  const [momentsRef, momentsApi] = useEmblaCarousel({ loop: true });
  const [supportersRef, supportersApi] = useEmblaCarousel({ loop: true });
  const [moment, setMoment] = useState(0);
  const [supporter, setSupporter] = useState(0);
  const [details, setDetails] = useState(false);
  const syncMoments = useCallback(
    () => setMoment(momentsApi?.selectedScrollSnap() ?? 0),
    [momentsApi],
  );
  const syncSupporters = useCallback(
    () => setSupporter(supportersApi?.selectedScrollSnap() ?? 0),
    [supportersApi],
  );
  useEffect(() => {
    momentsApi?.on("select", syncMoments);
    supportersApi?.on("select", syncSupporters);
    return () => {
      momentsApi?.off("select", syncMoments);
      supportersApi?.off("select", syncSupporters);
    };
  }, [momentsApi, supportersApi, syncMoments, syncSupporters]);
  const homeSupporters = supporters.slice(0, 5);
  const current = homeSupporters[supporter];
  return (
    <div className="mx-auto grid w-full max-w-7xl gap-6 px-3 py-5 sm:px-6 xl:grid-cols-[minmax(0,2.15fr)_minmax(0,1fr)] xl:gap-5 xl:py-10">
      <section
        aria-label="Momentos que ficam"
        className="min-w-0 rounded-sm border-[3px] border-border bg-card p-3 shadow-offset sm:p-5"
      >
        <header className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
          <div className="min-w-0">
            <p className="text-sm font-bold text-primary sm:text-lg">Nossa História</p>
            <h1 className="text-xl font-black leading-tight sm:text-2xl">Momentos que Ficam</h1>
          </div>
          <Button asChild variant="outline" size="icon" className="border-2" title="Ver galeria">
            <Link to="/galeria" aria-label="Ver galeria">
              <ArrowRight aria-hidden="true" />
            </Link>
          </Button>
        </header>
        <div ref={momentsRef} className="overflow-hidden rounded-sm border-2 border-border">
          <div className="flex touch-pan-y">
            {galleryItems.map((item, i) => (
              <figure key={item.id} className="min-w-0 flex-[0_0_100%]" aria-hidden={moment !== i}>
                <img
                  src={item.image}
                  alt={item.description}
                  width={item.width}
                  height={item.height}
                  fetchPriority={i === 0 ? "high" : undefined}
                  className="aspect-[2.35/1] w-full object-cover"
                />
                <figcaption className="min-h-20 border-t-2 border-border p-2 text-base leading-snug sm:min-h-24 sm:text-xl">
                  {i === 0 ? homeContent.caption : item.description}
                </figcaption>
              </figure>
            ))}
          </div>
        </div>
        <div
          className="mx-auto mt-4 grid min-h-14 max-w-xl grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-1 rounded-md border-2 border-border bg-card p-1 shadow-offset"
          aria-label="Controles dos momentos"
        >
          <Button
            variant="participate"
            size="icon"
            className="border-2 border-border"
            aria-label="Momento anterior"
            onClick={() => momentsApi?.scrollPrev()}
          >
            <ArrowLeft aria-hidden="true" />
          </Button>
          <div className="flex min-w-0 justify-center">
            {galleryItems.map((item, i) => (
              <Button
                key={item.id}
                variant="ghost"
                size="icon"
                className="h-11 w-11 min-w-0"
                aria-label={`Mostrar momento ${i + 1}`}
                aria-pressed={moment === i}
                onClick={() => momentsApi?.scrollTo(i)}
              >
                <span
                  className={`size-4 rounded-full border-[3px] border-foreground ${moment === i ? "bg-foreground" : "bg-card"}`}
                />
              </Button>
            ))}
          </div>
          <Button
            variant="participate"
            size="icon"
            className="border-2 border-border"
            aria-label="Próximo momento"
            onClick={() => momentsApi?.scrollNext()}
          >
            <ArrowRight aria-hidden="true" />
          </Button>
        </div>
      </section>
      <div className="grid min-w-0 gap-6 xl:grid-rows-[auto_1fr]">
        <section
          aria-labelledby="contato-titulo"
          className="rounded-lg border-[3px] border-border bg-card p-6 shadow-offset"
        >
          <h2 id="contato-titulo" className="mb-4 text-2xl font-bold text-primary">
            Contato
          </h2>
          <address className="grid gap-2 not-italic">
            {[
              {
                Icon: Phone,
                label: "Telefone/Whatsapp",
                text: contactStatus.whatsapp,
                href: homeContent.whatsappUrl,
              },
              {
                Icon: Facebook,
                label: "Facebook",
                text: contactStatus.facebook,
                href: homeContent.facebookUrl,
              },
              {
                Icon: Mail,
                label: "E-mail",
                text: contactStatus.email,
                href: `mailto:${contactStatus.email}`,
              },
            ].map(({ Icon, label, text, href }) => (
              <a
                key={label}
                href={href}
                className="grid min-h-14 grid-cols-[auto_minmax(0,1fr)] items-center gap-3 rounded-md transition-colors hover:bg-secondary focus-visible:ring-4 focus-visible:ring-ring"
              >
                <Icon className="size-7 text-primary" aria-hidden="true" />
                <span className="min-w-0 text-base font-semibold leading-tight">
                  <span className="block text-muted-foreground">{label}</span>
                  <span className="block break-words">{text}</span>
                </span>
              </a>
            ))}
          </address>
        </section>
        <section
          aria-labelledby="apoiadores-titulo"
          className="min-w-0 rounded-lg border-[3px] border-border bg-primary p-4 text-primary-foreground shadow-offset"
        >
          <div className="mb-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2">
            <h2 id="apoiadores-titulo" className="text-2xl font-bold">
              Apoiadores
            </h2>
            <Button
              asChild
              variant="outline"
              size="icon"
              className="border-2 text-foreground"
              title="Ver todos os apoiadores"
            >
              <Link to="/apoiadores" aria-label="Ver todos os apoiadores">
                <ArrowRight aria-hidden="true" />
              </Link>
            </Button>
          </div>
          <div
            ref={supportersRef}
            className="overflow-hidden rounded-md border border-border bg-background text-foreground"
          >
            <div className="flex touch-pan-y">
              {homeSupporters.map((item, i) => (
                <article
                  key={item.id}
                  aria-hidden={supporter !== i}
                  className="grid min-w-0 flex-[0_0_100%] grid-cols-[minmax(0,.85fr)_minmax(0,1.15fr)] items-center gap-3 p-2"
                >
                  <div className="grid aspect-square place-content-center rounded-md border border-border bg-card p-2 text-center">
                    <HeartHandshake className="mx-auto size-10 text-action" aria-hidden="true" />
                    <span className="mt-2 text-sm">Logo em atualização</span>
                  </div>
                  <div className="min-w-0">
                    <h3 className="break-words text-xl font-extrabold">{item.name}</h3>
                    <Button
                      variant="participate"
                      className="mt-4 border-2 border-border px-3"
                      tabIndex={supporter === i ? 0 : -1}
                      onClick={() => setDetails(true)}
                    >
                      Saiba mais
                    </Button>
                  </div>
                </article>
              ))}
            </div>
          </div>
          <div
            className="mt-4 grid grid-cols-[auto_minmax(0,1fr)_auto] items-center rounded-md border-2 border-border bg-card p-1 shadow-offset"
            aria-label="Controles dos apoiadores"
          >
            <Button
              variant="participate"
              size="icon"
              className="border-2 border-border"
              aria-label="Apoiador anterior"
              onClick={() => supportersApi?.scrollPrev()}
            >
              <ArrowLeft aria-hidden="true" />
            </Button>
            <div className="flex min-w-0 justify-center">
              {homeSupporters.map((item, i) => (
                <Button
                  key={item.id}
                  variant="ghost"
                  size="icon"
                  className="h-11 w-11 min-w-0"
                  aria-label={`Mostrar apoiador ${i + 1}`}
                  aria-pressed={supporter === i}
                  onClick={() => supportersApi?.scrollTo(i)}
                >
                  <span
                    className={`size-4 rounded-full border-[3px] border-foreground ${supporter === i ? "bg-foreground" : "bg-card"}`}
                  />
                </Button>
              ))}
            </div>
            <Button
              variant="participate"
              size="icon"
              className="border-2 border-border"
              aria-label="Próximo apoiador"
              onClick={() => supportersApi?.scrollNext()}
            >
              <ArrowRight aria-hidden="true" />
            </Button>
          </div>
        </section>
      </div>
      <Dialog open={details} onOpenChange={setDetails}>
        <DialogContent className="max-w-[calc(100%-2rem)] rounded-lg border-[3px] sm:max-w-lg [&>button]:min-h-11 [&>button]:min-w-11">
          <DialogTitle className="pr-10 text-2xl">{current?.name}</DialogTitle>
          <HeartHandshake className="size-16 text-primary" aria-hidden="true" />
          <DialogDescription className="text-base">
            Logotipo, descrição e site oficial em atualização.
          </DialogDescription>
          <Button asChild variant="outline">
            <Link to="/apoiadores">Ver apoiadores</Link>
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
