import { Link, useRouterState } from "@tanstack/react-router";
import {
  Accessibility,
  Moon,
  Sun,
  Facebook,
  Instagram,
  Mail,
  Menu,
  MessageCircle,
  Phone,
  X,
} from "lucide-react";
import { useEffect, useState, type ReactNode } from "react";
import { Button } from "@/components/ui/button";
import { contactStatus, homeContent } from "@/lib/site-content";
import brandLogo from "@/assets/mafe-brand-logo.asset.json";

const navItems = [
  { to: "/" as const, label: "Início" },
  { to: "/quem-somos" as const, label: "Quem Somos" },
  { to: "/galeria" as const, label: "Galeria" },
  { to: "/apoiadores" as const, label: "Apoiadores" },
];

export function SiteFrame({ children }: { children: ReactNode }) {
  const [highContrast, setHighContrast] = useState(false);
  const [dark, setDark] = useState(false);
  const [ready, setReady] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  useEffect(() => {
    const contrast = window.localStorage.getItem("mafe-alto-contraste") === "true";
    setHighContrast(contrast);
    setDark(window.localStorage.getItem("mafe-modo-escuro") === "true" && !contrast);
    setReady(true);
  }, []);
  useEffect(() => {
    if (!ready) return;
    document.documentElement.classList.toggle("dark", dark);
    document.documentElement.classList.toggle("high-contrast", highContrast);
    window.localStorage.setItem("mafe-modo-escuro", String(dark));
    window.localStorage.setItem("mafe-alto-contraste", String(highContrast));
  }, [ready, dark, highContrast]);
  useEffect(() => setMenuOpen(false), [pathname]);
  useEffect(() => {
    if (!menuOpen) return;
    const close = (event: KeyboardEvent) => {
      if (event.key === "Escape") setMenuOpen(false);
    };
    window.addEventListener("keydown", close);
    return () => window.removeEventListener("keydown", close);
  }, [menuOpen]);
  const toggleContrast = () => {
    setHighContrast((v) => !v);
    setDark(false);
  };
  const toggleDark = () => {
    setDark((v) => !v);
    setHighContrast(false);
  };
  return (
    <div className="min-h-dvh bg-background pb-36 text-foreground sm:pb-0">
      <a href="#conteudo" className="skip-link">
        Pular para o conteúdo
      </a>
      <header className="sticky top-0 z-40 border-b-4 border-primary bg-card">
        <div className="mx-auto grid min-h-20 max-w-7xl grid-cols-[minmax(0,1fr)_auto_auto_auto] items-center gap-2 px-3 py-3 sm:gap-4 sm:px-6 xl:min-h-24 xl:grid-cols-[minmax(0,1fr)_auto_auto_auto_auto]">
          <Link
            to="/"
            className="flex min-w-0 items-center gap-2 rounded-md focus-visible:ring-4 focus-visible:ring-ring sm:gap-4"
          >
            <span className="flex h-14 w-10 shrink-0 items-center justify-center rounded-md bg-logo-surface sm:h-20 sm:w-16">
              <img
                src={brandLogo.url}
                alt="Escudo VOLLEYBALL do MAFE"
                className="size-full object-contain"
              />
            </span>
            <span className="min-w-0">
              <span className="mb-2 block text-[9px] font-bold leading-tight text-primary sm:text-sm">
                Equipe de Voleibol Adaptado
              </span>
              <span className="block break-words text-xs font-black leading-tight sm:text-xl">
                <span className="text-primary">MA</span>TURIDADE{" "}
                <span className="text-primary">FE</span>LIZ
                <span className="hidden text-primary xl:inline"> (MAFE)</span>
              </span>
            </span>
          </Link>
          <nav aria-label="Navegação principal" className="hidden items-center gap-1 xl:flex">
            {navItems.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="nav-link px-3"
                activeProps={{ className: "nav-link nav-link-active px-3" }}
                activeOptions={{ exact: item.to === "/" }}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <Button
            variant="outline"
            size="icon"
            className="h-11 w-11 border-2 sm:h-12 sm:w-12"
            onClick={toggleContrast}
            aria-pressed={highContrast}
            aria-label={highContrast ? "Usar contraste normal" : "Ativar alto contraste"}
            title="Alto contraste"
          >
            <Accessibility aria-hidden="true" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-11 w-11 border-2 sm:h-12 sm:w-12"
            onClick={toggleDark}
            aria-pressed={dark}
            aria-label={dark ? "Usar modo claro" : "Ativar modo escuro"}
            title="Alternar tema"
          >
            {dark ? <Sun aria-hidden="true" /> : <Moon aria-hidden="true" />}
          </Button>
          <Button
            variant="participate"
            className="hidden border-2 border-border px-4 xl:inline-flex"
            asChild
          >
            <a href={homeContent.whatsappUrl}>Participar</a>
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-11 w-11 border-2 sm:h-12 sm:w-12 xl:hidden"
            onClick={() => setMenuOpen((v) => !v)}
            aria-expanded={menuOpen}
            aria-controls="menu-celular"
            aria-label={menuOpen ? "Fechar menu" : "Abrir menu"}
          >
            {menuOpen ? <X aria-hidden="true" /> : <Menu aria-hidden="true" />}
          </Button>
        </div>
        {menuOpen && (
          <nav
            id="menu-celular"
            aria-label="Menu para celular"
            className="absolute left-0 right-0 grid gap-2 border-b-2 border-primary bg-card px-5 py-3 shadow-offset xl:hidden"
          >
            {navItems.map((item) => (
              <Button
                key={item.to}
                asChild
                variant={pathname === item.to ? "secondary" : "outline"}
                className={
                  pathname === item.to
                    ? "font-extrabold underline decoration-primary decoration-4 underline-offset-4"
                    : "border border-border"
                }
              >
                <Link to={item.to}>{item.label}</Link>
              </Button>
            ))}
            <Button asChild variant="participate" className="border border-border">
              <a href={homeContent.whatsappUrl}>Participar</a>
            </Button>
          </nav>
        )}
      </header>
      <main id="conteudo" tabIndex={-1}>
        {children}
      </main>
      <footer className="fixed inset-x-0 bottom-0 z-30 border-t-4 border-primary bg-footer text-footer-foreground sm:static">
        <div className="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-x-3 gap-y-1 px-3 py-3 text-xs sm:px-6 sm:text-sm xl:grid-cols-[auto_auto_minmax(0,1fr)_auto] xl:gap-6">
          <a
            href="tel:+5511902439028"
            className="flex min-h-6 items-center gap-2 underline-offset-4 hover:underline sm:min-h-11"
          >
            <Phone className="size-4 shrink-0 sm:size-5" aria-hidden="true" />
            <span>contato: {homeContent.footerPhone}</span>
          </a>
          <a
            href={`mailto:${contactStatus.email}`}
            className="col-start-1 flex min-h-6 items-center gap-2 underline-offset-4 hover:underline sm:min-h-11 xl:col-auto"
          >
            <Mail className="size-4 shrink-0 sm:size-5" aria-hidden="true" />
            <span>Email: {contactStatus.email}</span>
          </a>
          <p className="col-span-2 mt-1 text-xs leading-snug sm:text-sm xl:col-span-1 xl:mt-0">
            Deseja a remoção de alguma foto? Entre em contato via WhatsApp ou e-mail.
          </p>
          <div className="col-start-2 row-start-1 row-end-3 flex items-center gap-2 xl:col-auto xl:row-auto">
            <Button
              asChild
              variant="ghost"
              size="icon"
              className="rounded-full bg-social-whatsapp text-logo-surface hover:bg-social-whatsapp/80"
              title="WhatsApp"
            >
              <a href={homeContent.whatsappUrl} aria-label="Conversar pelo WhatsApp">
                <MessageCircle className="fill-current" aria-hidden="true" />
              </a>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              disabled
              className="rounded-full bg-social-instagram text-logo-surface disabled:opacity-100"
              aria-label="Instagram — endereço em atualização"
              title="Instagram — endereço em atualização"
            >
              <Instagram aria-hidden="true" />
            </Button>
            <Button
              asChild
              variant="ghost"
              size="icon"
              className="rounded-full bg-social-facebook text-logo-surface hover:bg-social-facebook/80"
              title="Facebook"
            >
              <a href={homeContent.facebookUrl} aria-label="Acessar Facebook">
                <Facebook aria-hidden="true" />
              </a>
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
}
