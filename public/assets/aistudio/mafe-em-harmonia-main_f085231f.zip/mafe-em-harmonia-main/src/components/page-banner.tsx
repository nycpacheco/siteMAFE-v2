import { Volleyball } from "lucide-react";

export function PageBanner({
  eyebrow,
  title,
  text,
}: {
  eyebrow: string;
  title: string;
  text: string;
}) {
  return (
    <section className="relative overflow-hidden border-b-8 border-foreground bg-primary py-6 text-primary-foreground md:py-8">
      <Volleyball aria-hidden="true" className="absolute -right-6 -top-6 size-40 opacity-15" />
      <div className="page-shell relative">
        <span className="mb-1 block font-bold uppercase">{eyebrow}</span>
        <h1 className="font-display text-4xl font-black uppercase md:text-6xl">{title}</h1>
        <p className="mt-2 max-w-3xl text-lg font-bold md:text-xl">{text}</p>
      </div>
    </section>
  );
}
